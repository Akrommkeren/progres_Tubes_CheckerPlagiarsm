/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CheckerPlagiarsm;

import java.time.LocalDate;

/**
 *
 * @author ACER
 */
public class InputDokumen {
    private String judulDokumen;
    private String fileDokumen;
    private LocalDate tanggalInput;
    private String namaPenginput;

    // Konstruktor
    public InputDokumen(String judulDokumen, String fileDokumen, LocalDate tanggalInput, String namaPenginput) {
        this.judulDokumen = judulDokumen;
        this.fileDokumen = fileDokumen;
        this.tanggalInput = LocalDate.now();
        this.namaPenginput = namaPenginput;
    }

    // Getter dan Setter
    public String getJudulDokumen() {
        return judulDokumen;
    }

    public void setJudulDokumen(String judulDokumen) {
        this.judulDokumen = judulDokumen;
    }

    public String getFileDokumen() {
        return fileDokumen;
    }

    public void setFileDokumen(String fileDokumen) {
        this.fileDokumen = fileDokumen;
    }

    public String getNamainput() {
        return namaPenginput;
    }

    public void setNamainput(String namaPenginput) {
        this.namaPenginput = namaPenginput;
    }

    // Metode untuk menampilkan informasi dokumen yang diinput
    public void tampilkanInfoDokumen() {
        System.out.println("Dokumen berhasil diinput!");
        System.out.println("Judul Dokumen   : " + judulDokumen);
        System.out.println("File Dokumen    : " + fileDokumen);
        System.out.println("Tanggal Input   : " + tanggalInput);
        System.out.println("Nama Penginput  : " + namaPenginput);
    }
}
