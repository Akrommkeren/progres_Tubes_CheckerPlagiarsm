/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CheckerPlagiarsm;

/**
 *
 * @author ACER
 */
public class Mahasiswa extends Login{
    private String nama;
    private String nim;
    private String prodi;
    private String fakultas;
    
    public Mahasiswa(String nama, String nim, String prodi, String fakultas, String email, String password){
        super(email, password);
        this.nama = nama;
        this.nim = nim;
        this.prodi = prodi;
        this.fakultas = fakultas;
    }
    
    public String getNama(){
        return nama;
    }
    
    public String getNim(){
        return nim;
    }
    
    public void setNim(String nim){
        this.nim = nim;
    }
    
    public void inputFile(String dokumen){
        System.out.println(nama+" - Doumen berhasil diinput! "+dokumen);
    }
}
