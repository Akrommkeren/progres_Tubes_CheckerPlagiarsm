/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CheckerPlagiarsm;

/**
 *
 * @author ACER
 */
public class Main {
    public static void main(String[] args) {
        Mahasiswa mahasiswa = new Mahasiswa("Ali", "123456","Sistem Informasi","FRI", "ali@student.com", "password123");
        Dosen dosen = new Dosen("Dr. Budi", "789101", "budi@dosen.com", "password456");
        if (mahasiswa.veryfLogin("ali@student.com", "password123")) {
            System.out.println("Login Mahasiswa berhasil: " + mahasiswa.getNama());
        } else {
            System.out.println("Login gagal.");
        }
        if (dosen.veryfLogin("budi@dosen.com", "password456")) {
            System.out.println("Login Dosen berhasil: " + dosen.getNama());
        } else {
            System.out.println("Login gagal.");
        }
    }
}
