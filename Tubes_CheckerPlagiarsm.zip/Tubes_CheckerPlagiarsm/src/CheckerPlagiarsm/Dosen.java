/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CheckerPlagiarsm;

/**
 *
 * @author ACER
 */
public class Dosen extends Login{
    private String nama;
    private String nip;
    
    public Dosen(String nama, String nip, String email, String password){
        super(email, password);
        this.nama = nama;
        this.nip = nip;
    }
    
    public String getNama(){
        return nama;
    }
    
    public void setNama(){
        this.nama = nama;
    }
    
    public String getNip(){
        return nip;
    }
    
    public void setNip(String nip){
        this.nip = nip;
    }
    
    public void inputFile(String dokumen){
        System.out.println(nama+" - Doumen berhasil diinput! "+dokumen);
    }
}
